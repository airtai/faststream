## fastkafka.KafkaEvent {#fastkafka.KafkaEvent}

<a href="https://github.com/airtai/fastkafka/blob/main/fastkafka/_components/producer_decorator.py#L38-L48" class="link-to-source" target="_blank">View source</a>


A generic class for representing Kafka events. Based on BaseSubmodel, bound to pydantic.BaseModel

**Parameters**:

|  Name | Type | Description | Default |
|---|---|---|---|
| `message` | `BaseSubmodel` | The message contained in the Kafka event, can be of type pydantic.BaseModel. | *required* |
| `key` | `Optional[bytes]` | The optional key used to identify the Kafka event. | `None` |

### __init__ {#fastkafka.KafkaEvent.init}



```py
__init__(
    self, message, key=None
)
```

